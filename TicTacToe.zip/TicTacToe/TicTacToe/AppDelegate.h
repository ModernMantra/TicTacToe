//
//  AppDelegate.h
//  TicTacToe
//
//  Created by Kerim Njuhović on 4/28/14.
//  Copyright (c) 2014 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
