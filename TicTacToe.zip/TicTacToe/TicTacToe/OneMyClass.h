//
//  OneMyClass.h
//  TicTacToe
//
//  Created by Kerim Njuhović on 8/8/14.
//  Copyright (c) 2014 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OneMyClass : UIViewController

@end
