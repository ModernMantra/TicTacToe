//
//  ViewController.m
//  FirstApp
//
//  Created by Kerim Njuhović on 4/22/14.
//  Copyright (c) 2014 Kerim Njuhovic. All rights reserved.
//
# import <QuartzCore/QuartzCore.h>
#import "ViewController.h"



static double delayInSeconds;
static char array [3][3] = {'N','N','N','N','N','N','N','N','N'};
static int arrayIndexI = 4, arrayIndexJ = 4, lastValue [9], count = 0;
static NSString *alert = @"",*st1 = @" ", *st2 = @" ";
static UIAlertView *popUp, *brainPopUp;
static int brojac = 0, firstPlayer, counterX = 0, counterO = 0;
static BOOL alreadyPopped = false, painted = false;

@interface ViewController ()
-(char) nextplayer;
-(BOOL) stopPlaying;
-(void) destroy;
-(BOOL) arrayFull;

@end
@implementation ViewController
@synthesize backGroundColor,bEight,bFive,bFour,bNine,bOne,bSeven,bSix,bThree,bTwo, displayPlayer,screenshot;
@synthesize x = _x, y = _y;
@synthesize passingBackground, resetGame, settings,highscore1, highscore2, gameMode = _gameMode, TicTacLineColor,caShape1,caShape2,caLayer1,caLayer2,gameMode2;
int checker = 1 ;
int highScoreX = 0, highScoreO = 0,lastScoreX = 0,lastScoreO = 0;
// >>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<


- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"go"]){
        [self takeScreenshot];
        SecondView *sv = [segue destinationViewController];
        //     [self performSegueWithIdentifier:@"go" sender:self];
        sv.background = passingBackground;
        sv.delegate = self;
        [self pauseLayer:caLayer1];
        [self pauseLayer:caLayer2];
        [self pauseLayer:caShape1];
        [self pauseLayer:caShape2];
    }
    
}

-(void)viewWillAppear:(BOOL)animated{
    double delay = 1.6;
    dispatch_time_t pop = dispatch_time(DISPATCH_TIME_NOW, delay * NSEC_PER_SEC);
    dispatch_after(pop, dispatch_get_main_queue(), ^(void){
        [self resumeLayer:caShape1];[self resumeLayer:caLayer1];[self resumeLayer:caShape2];[self resumeLayer:caLayer2];});
    self.view.backgroundColor = backGroundColor;
    if ([_gameMode isEqualToString:gameMode2] == false) {
        [self destroy];
        NSString *classic;
        popUp = [[UIAlertView alloc] initWithTitle:@"Tic Tac Toe" message:nil delegate:nil cancelButtonTitle:nil
                                 otherButtonTitles:@"X",@"O", nil];
        classic = [NSString stringWithFormat:@"%@Select first player", alert];
        popUp.message = classic;
        popUp.delegate = self;
        [popUp setTag:1];
        double timing = 1.0;
        dispatch_time_t pop = dispatch_time(DISPATCH_TIME_NOW, timing * NSEC_PER_SEC);
        dispatch_after(pop, dispatch_get_main_queue(), ^(void){
            [popUp show];});
        gameMode2 = _gameMode;
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    _gameMode = @"Friends",gameMode2 = @"Friends";
    TicTacLineColor = @"Cyan";
    backGroundColor = [UIColor colorWithRed:255/255.0f green:124/255.0f blue:71/255.0f alpha:1.0f];
    self.view.backgroundColor = backGroundColor;
    displayPlayer.text = @"Next - ";
    [self alertAction];
    [self takeScreenshot];
    [self makeLineForWinners];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonOne:(id)sender{
    _x = bOne.frame.origin.x;
    _y = bOne.frame.origin.y;
    
    if ([self  doesContain:1] == FALSE){
        [self displayShape:_x and:_y];
        [self nextplayer];
        array [0][0] = [self nextplayer];
        if ([self stopPlaying] == TRUE && alreadyPopped == false) {
            alreadyPopped = true;
            [self disableDrawing];
            delayInSeconds = 1.0;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){[self alertAction];});
        }
        checker ++;
        if ([_gameMode isEqualToString:@"Brain"] == TRUE){
            [self checkGameFieldAndAct];
        }
        lastValue[0] = 1;
    }
}

- (IBAction)buttonTwo:(id)sender{
    _x = bTwo.frame.origin.x;
    _y = bTwo.frame.origin.y;
    
    if ([self doesContain:2] == FALSE){
        [self displayShape:_x and:_y];
        [self nextplayer];
        array [0][1] = [self nextplayer];
        if ([self stopPlaying] == TRUE && alreadyPopped == false) {
            alreadyPopped = true;
            [self disableDrawing];
            delayInSeconds = 1.1;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){[self alertAction];});
        }
        checker ++;
        if ([_gameMode isEqualToString:@"Brain"] == TRUE){
            [self checkGameFieldAndAct];
        }
        lastValue[1] = 2;
    }
}

- (IBAction)buttonThree:(id)sender{
    _x = bThree.frame.origin.x;
    _y = bThree.frame.origin.y;
    if ([self doesContain:3] == FALSE){
        [self displayShape:_x and:_y];
        [self nextplayer];
        array [0][2] = [self nextplayer];
        if ([self stopPlaying] == TRUE && alreadyPopped == false) {
            alreadyPopped = true;
            [self disableDrawing];
            delayInSeconds = 1.1;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){[self alertAction];});
        }
        checker ++;
        if ([_gameMode isEqualToString:@"Brain"] == TRUE){
            [self checkGameFieldAndAct];
        }
        lastValue [2] = 3;
    }
}

- (IBAction)buttonFour:(id)sender{
    _x = bFour.frame.origin.x;
    _y = bFour.frame.origin.y;
    if ([self doesContain:4] == FALSE){
        [self displayShape:_x and:_y];
        [self nextplayer];
        array [1][0] = [self nextplayer];
        if ([self stopPlaying] == TRUE && alreadyPopped == false) {
            alreadyPopped = true;
            [self disableDrawing];
            delayInSeconds = 1.1;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){[self alertAction];});
        }
        checker ++;
        if ([_gameMode isEqualToString:@"Brain"] == TRUE){
            [self checkGameFieldAndAct];
        }
        lastValue [3] = 4;
    }
}

- (IBAction)buttonFive:(id)sender{
    _x = bFive.frame.origin.x;
    _y = bFive.frame.origin.y;
    if ([self doesContain:5] == FALSE){
        [self displayShape:_x and:_y];
        [self nextplayer];
        array [1][1] = [self nextplayer];
        if ([self stopPlaying] == TRUE && alreadyPopped == false) {
            alreadyPopped = true;
            [self disableDrawing];
            delayInSeconds = 1.1;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){[self alertAction];});
        }
        checker ++;
        if ([_gameMode isEqualToString:@"Brain"] == TRUE){
            [self checkGameFieldAndAct];
        }
        lastValue [4] = 5;
    }
}

- (IBAction)buttonSix:(id)sender{
    _x = bSix.frame.origin.x;
    _y = bSix.frame.origin.y;
    if ([self doesContain:6] == FALSE){
        [self displayShape:_x and:_y];
        [self nextplayer];
        array [1][2] = [self nextplayer];
        if ([self stopPlaying] == TRUE && alreadyPopped == false) {
            alreadyPopped = true;
            [self disableDrawing];
            delayInSeconds = 1.1;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){[self alertAction];});
        }
        checker ++;
        if ([_gameMode isEqualToString:@"Brain"] == TRUE){
            [self checkGameFieldAndAct];
        }
        lastValue [5] = 6;
    }
}

- (IBAction)buttonSeven:(id)sender{
    _x = bSeven.frame.origin.x;
    _y = bSeven.frame.origin.y;
    if ([self doesContain:7] == FALSE){
        [self displayShape:_x and:_y];
        [self nextplayer];
        array [2][0] = [self nextplayer];
        if ([self stopPlaying] == TRUE && alreadyPopped == false) {
            alreadyPopped = true;
            [self disableDrawing];
            delayInSeconds = 1.1;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){[self alertAction];});
        }
        checker ++;
        if ([_gameMode isEqualToString:@"Brain"] == TRUE){
            [self checkGameFieldAndAct];
        }
        lastValue [6] = 7;
    }
}


- (IBAction)buttonEight:(id)sender{
    _x = bEight.frame.origin.x;
    _y = bEight.frame.origin.y;
    if ([self doesContain:8] == FALSE){
        [self displayShape:_x and:_y];
        [self nextplayer];
        array [2][1] = [self nextplayer];
        if ([self stopPlaying] == TRUE && alreadyPopped == false) {
            alreadyPopped = true;
            [self disableDrawing];
            delayInSeconds = 1.1;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){[self alertAction];});
        }
        checker ++;
        if ([_gameMode isEqualToString:@"Brain"] == TRUE){
            [self checkGameFieldAndAct];
        }
        lastValue [7] = 8;
    }
}

- (IBAction)buttonNine:(id)sender{
    _x = bNine.frame.origin.x;
    _y = bNine.frame.origin.y;
    if ([self doesContain:9] == FALSE){
        [self displayShape:_x and:_y];
        [self nextplayer];
        array [2][2] = [self nextplayer];
        if ([self stopPlaying] == TRUE && alreadyPopped == false) {
            alreadyPopped = true;
            [self disableDrawing];
            delayInSeconds = 1.1;
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){[self alertAction];});
        }
        checker ++;
        if ([_gameMode isEqualToString:@"Brain"] == TRUE){
            [self checkGameFieldAndAct];
        }
        lastValue [8] = 9;
    }
}

- (IBAction)settingsButton:(id)sender{
    
}

-(char) nextplayer{
    char character = 'k';
    if (painted == false) {
        [self drawCircleForX];
        [self drawCircleForO];
        painted = true;
    }
    if (checker %2 == 0){
        character = 'O';
        displayPlayer.text = @"Next - X";
    }
    else {
        character = 'X';
        displayPlayer.text = @"Next - O";
    }
    [self playSound];
    return character;
}

-(void)displayShape:(CGFloat)xCoordinate and:(CGFloat) yCoordinate{
    if (checker %2 == 1){
        [self makeX:xCoordinate and:yCoordinate];}
    else {
        [self makeCircleWith:xCoordinate and:yCoordinate];
    }
}

-(BOOL) stopPlaying{
    
    if ((array [0][0] == array [0][1])&&(array [0][1] == array [0][2])
        && (array [0][2] == 'X')){
        alert = @"The winner is player X! ";
        [self stopClockFor:@"X"];
        highScoreX ++;
        return true;
    }
    else if((array [0][0] == array [0][1])&&(array [0][1] == array [0][2])
            && (array [0][2] == 'O')){
        alert = @"The winner is player O! ";
        [self stopClockFor:@"O"];
        highScoreO ++;
        return  true;
    }
    else if((array [2][0] == array [2][1])&&(array [2][1] == array [2][2])
            && (array [2][2] == 'X')){
        alert = @"The winner is player X! ";
        [self stopClockFor:@"X"];
        highScoreX ++;
        return  true;
    }
    else if ((array [2][0] == array [2][1])&&(array [2][1] == array [2][2])
             && (array [2][2] == 'O')){
        alert = @"The winner is player O! ";
        [self stopClockFor:@"O"];
        highScoreO ++;
        return  true;
    }
    else if((array [1][0] == array [1][1])&&(array [1][1] == array [1][2])
            && (array [1][2] == 'X')){
        alert = @"The winner is player X! ";
        [self stopClockFor:@"X"];
        highScoreX ++;
        return  true;
    }
    else if ((array [1][0] == array [1][1])&&(array [1][1] == array [1][2])
             && (array [1][2] == 'O')){
        alert = @"The winner is player O! ";
        [self stopClockFor:@"O"];
        highScoreO ++;
        return  true;
    }
    else if((array [0][0] == array [1][0])&&(array [1][0] == array [2][0])
            && (array [2][0] == 'X')){
        alert = @"The winner is player X! ";
        [self stopClockFor:@"X"];
        highScoreX ++;
        return  true;
    }
    else if ((array [0][0] == array [1][0])&&(array [1][0] == array [2][0])
             && (array [2][0] == 'O')){
        alert = @"The winner is player O! ";
        [self stopClockFor:@"O"];
        highScoreO ++;
        return  true;
    }
    else if((array [0][1] == array [1][1])&&(array [1][1] == array [2][1])
            && (array [2][1] == 'X')){
        alert = @"The winner is player X! ";
        [self stopClockFor:@"X"];
        highScoreX ++;
        return  true;
    }
    else if ((array [0][1] == array [1][1])&&(array [1][1] == array [2][1])
             && (array [2][1] == 'O')){
        alert = @"The winner is player O! ";
        [self stopClockFor:@"O"];
        highScoreO ++;
        return  true;
    }
    else if((array [0][2] == array [1][2])&&(array [1][2] == array [2][2])
            && (array [2][2] == 'X')){
        alert = @"The winner is player X! ";
        [self stopClockFor:@"X"];
        highScoreX ++;
        return  true;
    }
    else if ((array [0][2] == array [1][2])&&(array [1][2] == array [2][2])
             && (array [2][2] == 'O')){
        alert = @"The winner is player O! ";
        [self stopClockFor:@"O"];
        highScoreO ++;
        return  true;
    }
    else if((array [0][0] == array [1][1])&&(array [1][1] == array [2][2])
            && (array [2][2] == 'X')){
        alert = @"The winner is player X! ";
        [self stopClockFor:@"X"];
        highScoreX ++;
        return  true;
    }
    else if ((array [0][0] == array [1][1])&&(array [1][1] == array [2][2])
             && (array [2][2] == 'O')){
        alert = @"The winner is player O! ";
        [self stopClockFor:@"O"];
        highScoreO ++;
        return  true;
    }
    else if((array [2][0] == array [1][1])&&(array [1][1] == array [0][2])
            && (array [0][2] == 'X')){
        alert = @"The winner is player X! ";
        [self stopClockFor:@"X"];
        highScoreX ++;
        return  true;
    }
    else if ((array [2][0] == array [1][1])&&(array [1][1] == array [0][2])
             && (array [0][2] == 'O')){
        alert = @"The winner is player O! ";
        [self stopClockFor:@"O"];
        highScoreO ++;
        return true;
    }
    else if ([self arrayFull] == TRUE){
        [self stopClockFor:@"Both"];
        alert = @"Tie! ";
        return true;
    }
    return false;
}

-(void) destroy {
    
    displayPlayer.text = @"Next - ";
    for (int column = 0; column < 3; column++) {
        for (int row = 0; row < 3; row ++) {
            array [column][row] = 'N';}
    }
    for (int i = 0; i < 9; i ++) {
        lastValue [i] = 0;
    }
    for (int k = 0; k < brojac; k++) {
        [[self.view.layer.sublayers objectAtIndex:0] removeFromSuperlayer];
    }
    brojac = 0;
    arrayIndexI = 4,arrayIndexJ = 4;
    alreadyPopped = false;
}

-(BOOL) arrayFull {
    int counter = 0;
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (array [i][j] != 'N')
                counter ++;}
    }
    if (counter == 9){
        return true;
    }
    else{
        return false;
    }
}

-(void) alertAction {
    count ++;
    NSString *classic;
    popUp = [[UIAlertView alloc] initWithTitle:@"Tic Tac Toe" message:nil delegate:nil cancelButtonTitle:nil
                             otherButtonTitles:@"X",@"O", nil];
    classic = [NSString stringWithFormat:@"%@Select first player", alert];
    popUp.message = classic;
    popUp.delegate = self;
    [popUp setTag:1];
    [popUp show];
    lastScoreO = highScoreO, lastScoreX = highScoreX;
    
    if (lastScoreX > lastScoreO){
        st1 = [st1 stringByAppendingString:@"• "];
        highscore1.text = st1;
        counterX ++;
    }
    if (lastScoreO > lastScoreX){
        st2 = [st2 stringByAppendingString:@"• "];
        highscore2.text = st2;
        counterO ++;
    }
    if (counterO == 6 || counterX == 6){
        st1 = @" ", st2 = @" ";
        highscore1.text = st1, highscore2.text = st2;
        if (counterO > counterX){
            counterO = 0;
            st2 = [st2 stringByAppendingString:@"• "];
            highscore2.text = st2;
            counterO ++;
        }
        else {
            counterX = 0;
            st1 = [st1 stringByAppendingString:@"• "];
            highscore1.text = st1;
            counterX ++;
        }
    }
    
    [popUp show];
    highScoreO = 0;
    highScoreX = 0;
}

- (void) alertView: (UIAlertView*) alertView didDismissWithButtonIndex:(NSInteger)buttonIndex{
    if ([_gameMode isEqualToString:@"Brain"]== true && alertView.tag == 1){
        brainPopUp = [[UIAlertView alloc] initWithTitle:@"Tic Tac Toe" message:@"Who plays first?" delegate:nil cancelButtonTitle:nil otherButtonTitles:@"User",@"Computer", nil];
        brainPopUp.delegate = self;
        [brainPopUp setTag:2];
        [brainPopUp show];
    }
}

-(void) alertView: (UIAlertView *) alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (alertView.tag == 1){
        if ((int)buttonIndex == 0){
            checker = 1;
            [self destroy];
        }
        else {
            checker = 0;
            [self destroy];
        }
    }
    if (alertView.tag == 2){
        if ((int) buttonIndex == 0){
            //"User";
            firstPlayer = 0;
        }
        else {
            //"Brain"
            firstPlayer = 1;
            [self checkGameFieldAndAct];
        }
    }
}

- (BOOL) doesContain:(int) number {
    for (int i = 0; i < 9; i ++) {
        if (lastValue[number - 1] != 0){
            return true;
        }
    }
    return false;
}

-(void)makeCircleWith:(CGFloat)xCoordinate and:(CGFloat)yCoordinate{
    
    int radius = 20;
    CAShapeLayer *circle = [CAShapeLayer layer];
    circle.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(12.0, 12.0, 2.0*radius, 2.0*radius)
                   
                                             cornerRadius:radius].CGPath;
    circle.position = CGPointMake(xCoordinate, yCoordinate);
    circle.fillColor = [UIColor clearColor].CGColor;
    circle.strokeColor = [self returnTicTacColor].CGColor;
    circle.lineWidth = 2;
    
    [self.view.layer insertSublayer:circle atIndex:0];
    CABasicAnimation *drawAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    
    drawAnimation.duration            = 0.5; // 0.5
    drawAnimation.repeatCount         = 1.0;  // Animate only once..
    
    drawAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
    drawAnimation.toValue   = [NSNumber numberWithFloat:1.0f];
    [circle addAnimation:drawAnimation forKey:@"drawCircleAnimation"];
    brojac ++;
}

-(void) makeX:(CGFloat)xCoordinate and:(CGFloat)yCoordinate{
    
    CAShapeLayer *line = [CAShapeLayer layer];
    UIBezierPath *linePath = [UIBezierPath bezierPath];
    [linePath moveToPoint:CGPointMake(xCoordinate + 13,yCoordinate + 12)];
    [linePath addLineToPoint:CGPointMake(xCoordinate + 48 , yCoordinate + 48)];
    [linePath moveToPoint:CGPointMake(xCoordinate + 48 , yCoordinate + 12)];
    [linePath addLineToPoint:CGPointMake(xCoordinate + 13, yCoordinate + 48)];
    line.path = linePath.CGPath;
    line.fillColor = nil;
    line.opacity = 1.0;
    line.lineWidth = 2;
    line.strokeColor = [self returnTicTacColor].CGColor;
    [self.view.layer insertSublayer:line atIndex:0];
    CABasicAnimation *drawAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    
    drawAnimation.duration            = 0.5; // 0.5
    drawAnimation.repeatCount         = 1.0;  // Animate only once..
    drawAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
    drawAnimation.toValue   = [NSNumber numberWithFloat:1.0f];
    [line addAnimation:drawAnimation forKey:@"drawCircleAnimation"];
    brojac ++;
}

-(void) disableDrawing {
    for (int k = 0; k < 9; k++) {
        lastValue[k] = k + 1;
    }
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j ++) {
            array[i][j] = 'K';
        }
    }
}

- (void) takeScreenshot {
    UIGraphicsBeginImageContext(self.view.bounds.size);
    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
    screenshot = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    passingBackground = [self blur:screenshot];
}

- (UIImage*) blur:(UIImage*)theImage{
    
    CIContext *context = [CIContext contextWithOptions:nil];
    CIImage *inputImage = [CIImage imageWithCGImage:theImage.CGImage];
    CIFilter *filter = [CIFilter filterWithName:@"CIGaussianBlur"];
    [filter setValue:inputImage forKey:kCIInputImageKey];
    [filter setValue:[NSNumber numberWithFloat:8.0f] forKey:@"inputRadius"];
    CIImage *result = [filter valueForKey:kCIOutputImageKey];
    CGImageRef cgImage = [context createCGImage:result fromRect:[inputImage extent]];
    UIImage *returnImage = [UIImage imageWithCGImage:cgImage];
    CGImageRelease(cgImage);
    
    return returnImage;
}
- (IBAction)reset:(id)sender {
    [self destroy];
    NSString *classic;
    alert = @" ";
    [self alertAction];
    highscore1.text = @" ", highscore2.text = @" ";
    popUp.message = classic, popUp.delegate = self;
    [popUp show];
    highScoreX = 0,highScoreO = 0, lastScoreO = 0;
    st1 = @" ", st2 = @" ";
    lastScoreX = 0, arrayIndexI = 5, arrayIndexJ = 5;
    alreadyPopped = false;
}
-(void) playSound {
    SystemSoundID soundId;
    NSString *file = [[NSBundle mainBundle] pathForResource:@"click" ofType:@"wav"];
    AudioServicesCreateSystemSoundID((__bridge CFURLRef)([NSURL fileURLWithPath:file]), &soundId);
    AudioServicesPlaySystemSound(soundId);
}

-(void) checkGameFieldAndAct {
    if ([self twoInRow] == false && array[1][1] == 'N'){
        [self displayShape:bFive.frame.origin.x and:bFive.frame.origin.y];
        [self nextplayer];
        array[1][1] = [self nextplayer];
        lastValue[4] = 5;
        [self theEnd];
        checker ++;
    }
    else if ((array[1][1] != 'N' && [self twoInRow] == false)&&(array[0][0] == 'N' || array[0][2] == 'N' || array[2][0] == 'N' || array[2][2] == 'N')){
        
        int k = -1, l = -1;
        bool stop = false;
        
        for (int j = 0; j < 3; j++) {
            if (array [0][j] == 'N'){
                k = 0;
                l = j;
                stop = true;}
        }
        if (stop == false){
            for (int j = 0; j < 3; j++) {
                if (array [1][j] == 'N'){
                    k = 1;
                    l = j;
                    stop = true;}
            }
        }
        if (stop == false){
            for (int j = 0; j < 3; j++) {
                if (array [2][j] == 'N'){
                    k = 0;
                    l = j;
                    stop = true;}
            }
        }
        [self displayShape:[self ButtonWithIndex:k and:l].frame.origin.x and:[self ButtonWithIndex:k and:l].frame.origin.y];
        [self nextplayer];
        array[k][l] = [self nextplayer];
        lastValue[[self returnNumberForIndex:k and:l]] = [self returnNumberForIndex:k and:l]+1;
        [self theEnd];
        checker ++;
    }
    else if ([self twoInRow] == true && array[arrayIndexI][arrayIndexJ] == 'N'){
        [self displayShape:[self ButtonWithIndex:arrayIndexI and:arrayIndexJ].frame.origin.x and:[self ButtonWithIndex:arrayIndexI and:arrayIndexJ].frame.origin.y];
        [self nextplayer];
        array[arrayIndexI][arrayIndexJ] = [self nextplayer];
        lastValue[[self returnNumberForIndex:arrayIndexI and:arrayIndexJ]] = [self returnNumberForIndex:arrayIndexI and:arrayIndexJ]+1;
        [self theEnd];
        checker ++;
    }
    else if ([self twoInRow] == true && array[arrayIndexI][arrayIndexJ] != 'N' && [self arrayFull] == false){
        int k = 5, l = 5;
        bool stop = false;
        if (stop == false) {
            for (int j = 0; j < 3; j++) {
                if (array [0][j] == 'N'){
                    k = 0;
                    l = j;
                    stop = true;}
            }
        }
        if (stop == false){
            for (int j = 0; j < 3; j++) {
                if (array [1][j] == 'N'){
                    k = 1;
                    l = j;
                    stop = true;}
            }
        }
        if (stop == false){
            for (int j = 0; j < 3; j++) {
                if (array [2][j] == 'N'){
                    k = 0;
                    l = j;
                    stop = true;}
            }
        }
        [self displayShape:[self ButtonWithIndex:k and:l].frame.origin.x and:[self ButtonWithIndex:k and:l].frame.origin.y];
        [self nextplayer];
        array[k][l] = [self nextplayer];
        lastValue[[self returnNumberForIndex:k and:l]] = [self returnNumberForIndex:k and:l]+1;
        [self theEnd];
        checker ++;
    }
}
-(void)theEnd{
    if ([self stopPlaying] == TRUE && alreadyPopped == false) {
        alreadyPopped = true;
        [self disableDrawing];
        delayInSeconds = 1.1;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [self alertAction];});}
}

- (BOOL) twoInRow{
    BOOL stop = false;
    int a = 10;
    int b = 10;
    // checking all 3 rows whether contains dangerous field
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 1; j ++) {
            
            // checking all 3 rows whether contains dangerous field _
            if ((array[i][j] == array[i][j+1]) && (array[i][j] != 'N') && (array[i][j+1] != 'N')){
                stop = true;
                a = i;
                b = j+2;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
            if ((array[i][j] == array[i][j+2]) && (array[i][j] != 'N') && (array[i][j+2] != 'N')){
                stop = true;
                a = i;
                b = j+1;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
            if ((array[i][j+1] == array[i][j+2]) && (array[i][j+1] != 'N') && (array[i][j+2] != 'N')){
                stop = true;
                a = i;
                b = j;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
            //checking all 3 columns |
            if ((array[j][i] == array[j+1][i]) && (array[j][i] != 'N') && (array[j+1][i] != 'N')){
                stop = true;
                a = j+2;
                b = i;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
            if ((array[j][i] == array[j+2][i]) && (array[j][i] != 'N') && (array[j+2][i] != 'N')){
                stop = true;
                a = j+1;
                b = i;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
            if ((array[j+1][i] == array[j+2][i]) && (array[j+1][i] != 'N') && (array[j+2][i] != 'N')){
                stop = true;
                a = j;
                b = i;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
            // checking '\'
            if ((array[j][j] == array[j+1][j+1]) && (array[j][j] != 'N') && (array[j+1][j+1] != 'N')){
                stop = true;
                a = j+2;
                b = j+2;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
            if ((array[j][j] == array[j+2][j+2]) && (array[j][j] != 'N') && (array[j+2][j+2] != 'N')){
                stop = true;
                a = j+1;
                b = j+1;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
            if ((array[j+1][j+1] == array[j+2][j+2]) && (array[j+1][j+1] != 'N') && (array[j+2][j+2] != 'N')){
                stop = true;
                a = j;
                b = j;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
            // checking '/'
            if ((array[j][j+2] == array[j+1][j+1]) && (array[j][j+2] != 'N') && (array[j+1][j+1] != 'N')){
                stop = true;
                a = j+2;
                b = j;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
            if ((array[j][j+2] == array[j+2][j]) && (array[j][j+2] != 'N') && (array[j+2][j] != 'N')){
                stop = true;
                a = j+1;
                b = j+1;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
            if ((array[j+2][j] == array[j+1][j+1]) && (array[j+2][j] != 'N') && (array[j+1][j+1] != 'N')){
                stop = true;
                a = j;
                b = j+2;
                if (array[a][b] == 'N'){
                    arrayIndexI = a;
                    arrayIndexJ = b;
                }
            }
        }
    }
    return stop;
}
// returns button which corresponds to array[][]
-(UIButton*) ButtonWithIndex:(int)i and:(int)j {
    if (i == 0 && j == 0) {
        return bOne;
    }
    else if (i == 0 && j == 1){
        return bTwo;
    }
    else if (i == 0 && j == 2){
        return bThree;
    }
    else if (i == 1 && j == 0){
        return bFour;
    }
    else if (i == 1 && j == 1){
        return bFive;
    }
    else if (i == 1 && j == 2){
        return bSix;
    }
    else if (i == 2 && j == 0){
        return bSeven;
    }
    else if (i == 2 && j == 1){
        return bEight;
    }
    else
        return bNine;
}
- (int) returnNumberForIndex:(int)indexI and:(int)indexJ {
    
    if (indexI == 0 && indexJ == 0){
        return 0;
    }
    else if (indexI == 0 && indexJ == 1){
        return 1;
    }
    else if (indexI == 0 && indexJ == 2){
        return 2;
    }
    else if (indexI == 1 && indexJ == 0){
        return  3;
    }
    else if (indexI == 1 && indexJ == 1){
        return  4;
    }
    else if ( indexI == 1 && indexJ == 2){
        return  5;
    }
    else if ( indexI == 2 && indexJ == 0 ){
        return 6;
    }
    else if (indexI == 2 && indexJ == 1){
        return 7;
    }
    return 8;
}

-(void)makeLineForWinners{
    CAShapeLayer *line = [CAShapeLayer layer];
    UIBezierPath *linePath = [UIBezierPath bezierPath];
    [linePath moveToPoint:CGPointMake(75, 390 )];
    [linePath addLineToPoint:CGPointMake(240, 390)];
    line.path = linePath.CGPath;
    line.fillColor = nil;
    line.opacity = 1.0;
    line.lineWidth = 1.2;
    line.strokeColor = [UIColor darkGrayColor].CGColor;
    [self.view.layer insertSublayer:line atIndex:2];
    
    CAShapeLayer *halfCircle = [CAShapeLayer layer];
    halfCircle.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0,0,71, 12) cornerRadius:7].CGPath;
    halfCircle.position = CGPointMake(166, 422.5);
    halfCircle.fillColor = [UIColor clearColor].CGColor;
    halfCircle.strokeColor = [UIColor whiteColor].CGColor;
    halfCircle.lineWidth = 1.2;
    [self.view.layer insertSublayer:halfCircle atIndex:80];
    
    CAShapeLayer *SecondhalfCircle = [CAShapeLayer layer];
    SecondhalfCircle.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0,0,71, 12) cornerRadius:7].CGPath;
    SecondhalfCircle.position = CGPointMake(166, 487.5); // 75,406
    SecondhalfCircle.fillColor = [UIColor clearColor].CGColor;
    SecondhalfCircle.strokeColor = [UIColor whiteColor].CGColor;
    SecondhalfCircle.lineWidth = 1.2;
    
    [self.view.layer insertSublayer:SecondhalfCircle atIndex:90];
}

# pragma mark Protocol methods
-(void) passGameModeBack:(NSString *)ModeOfGame{
    if ([ModeOfGame isEqualToString:_gameMode] == false) {
        _gameMode = ModeOfGame;
    }
    else{
        _gameMode = ModeOfGame;
    }
}
-(void) passBackgroundColor:(float)red and:(float)green and:(float)blue and:(float)alpha{
    backGroundColor = [UIColor colorWithRed:red green:green blue:blue alpha:alpha];
}
-(void) passXandOlineColor:(NSString*)color{
    if ([color isEqualToString:TicTacLineColor] == false) {
        [self destroy];
        TicTacLineColor = color;
        [self returnTicTacColor];
    }
    else {
        TicTacLineColor = color;
    }
}
- (UIColor*)returnTicTacColor{
    if ([TicTacLineColor isEqualToString:@"Cyan"]== true){
        return [UIColor cyanColor];}
    else
        return  [UIColor grayColor];
}

- (void) drawCircleForX{
    caShape1 = [CAShapeLayer layer];
    caShape1.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0,0, 50, 50) cornerRadius:25].CGPath;
    //  circle.cornerRadius = 100;
    caShape1.position = CGPointMake(75, 406); // 75,406
    caShape1.fillColor = [UIColor clearColor].CGColor;
    caShape1.strokeColor = [UIColor whiteColor].CGColor;
    caShape1.lineWidth = 1.2;
    [self.view.layer insertSublayer:caShape1 atIndex:30];
    
    CABasicAnimation *drawAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    drawAnimation.duration = 59.9;
    drawAnimation.repeatCount = HUGE_VALF;  // Animate to...
    caShape1.strokeEnd = 1.0;
    drawAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
    drawAnimation.toValue   = [NSNumber numberWithFloat:1.0f];
    [caShape1 addAnimation:drawAnimation forKey:@"drawCircleAnimation"];
    [self.view.layer addSublayer:caShape1];
    
    caLayer1 = [CALayer layer];
	caLayer1.bounds = CGRectMake(0, 0, 50, 50);
	caLayer1.position = CGPointMake(100, 430); // 100, 430
	caLayer1.cornerRadius = 25;
	caLayer1.borderColor = [UIColor clearColor].CGColor;
	caLayer1.borderWidth = 1.2;
	
	CALayer *dot = [CALayer layer];
	dot.bounds = CGRectMake(0, 0, 7, 7);
	dot.position = CGPointMake(28, 1);
	dot.cornerRadius = 4;
	dot.backgroundColor = [UIColor whiteColor].CGColor;
	[caLayer1 addSublayer:dot];
	
	CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
	animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
	animation.fromValue = [NSNumber numberWithFloat:0];
	animation.toValue = [NSNumber numberWithFloat:((360*M_PI)/180)];
	animation.repeatCount = HUGE_VALF;
	animation.duration = 59.9;
	[caLayer1 addAnimation:animation forKey:@"transform"];
    
	[self.view.layer addSublayer:caLayer1];
    [self.view.layer insertSublayer:caLayer1 atIndex:40];
    
}

- (void) drawCircleForO{
    caShape2 = [CAShapeLayer layer];
    caShape2.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0,0, 50, 50) cornerRadius:25].CGPath;
    caShape2.position = CGPointMake(75, 470); // 75,406
    caShape2.fillColor = [UIColor clearColor].CGColor;
    caShape2.strokeColor = [UIColor whiteColor].CGColor;
    caShape2.lineWidth = 1.2;
    [self.view.layer insertSublayer:caShape2 atIndex:40];
    
    CABasicAnimation *drawAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    drawAnimation.duration = 59.9; // 0.5
    drawAnimation.repeatCount = HUGE_VALF;  // Animate...
    drawAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
    drawAnimation.toValue   = [NSNumber numberWithFloat:1.0f];
    [caShape2 addAnimation:drawAnimation forKey:@"drawCircleAnimation"];
    [self.view.layer addSublayer:caShape2];
    
    caLayer2 = [CALayer layer];
	caLayer2.bounds = CGRectMake(0, 0, 50, 50);
	caLayer2.position = CGPointMake(100, 494); // 100, 430
	caLayer2.cornerRadius = 25;
	caLayer2.borderColor = [UIColor clearColor].CGColor;
	caLayer2.borderWidth = 1.5;
    
	CALayer *dot = [CALayer layer];
	dot.bounds = CGRectMake(0, 0, 7, 7);
	dot.position = CGPointMake(28, 1);
	dot.cornerRadius = 4;
	dot.backgroundColor = [UIColor whiteColor].CGColor;
	[caLayer2 addSublayer:dot];
	
	CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
	animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
	animation.fromValue = [NSNumber numberWithFloat:0];
	animation.toValue = [NSNumber numberWithFloat:(360*(M_PI)/180)];
	animation.repeatCount = HUGE_VALF;
	animation.duration = 59.9;
	[caLayer2 addAnimation:animation forKey:@"transform"];
    
	[self.view.layer addSublayer:caLayer2];
    [self.view.layer insertSublayer:caLayer2 atIndex:60];
}

-(void)pauseLayer:(CALayer*)layer{
    CFTimeInterval pausedTime = [layer convertTime:CACurrentMediaTime() fromLayer:nil];
    layer.speed = 0.0;
    layer.timeOffset = pausedTime;
}

-(void)resumeLayer:(CALayer*)layer{
    CFTimeInterval pausedTime = [layer timeOffset];
    layer.speed = 1.0;
    layer.timeOffset = 0.0;
    layer.beginTime = 0.0;
    CFTimeInterval timeSincePause = [layer convertTime:CACurrentMediaTime() fromLayer:nil] - pausedTime;
    layer.beginTime = timeSincePause;
}

- (void) enableForFunction:(CALayer*)layer andShape:(CAShapeLayer*)shapeLayer{
    [self resumeLayer:layer];
    [self resumeLayer:shapeLayer];
}
-(void)stopClockFor:(NSString*)sign{
    double delay = 0.5;
    if ([sign isEqualToString:@"X"] == true){
        dispatch_time_t pop = dispatch_time(DISPATCH_TIME_NOW, delay * NSEC_PER_SEC);
        dispatch_after(pop, dispatch_get_main_queue(), ^(void){
            [self pauseLayer:caShape1];[self pauseLayer:caLayer1];});
        delay += 1.5;
        dispatch_time_t pop1 = dispatch_time(DISPATCH_TIME_NOW, delay * NSEC_PER_SEC);
        dispatch_after(pop1, dispatch_get_main_queue(), ^(void){
            [self resumeLayer:caShape1];[self resumeLayer:caLayer1];});
    }
    else if ([sign isEqual:@"O"] == true) {
        delay = 0.5;
        dispatch_time_t pop2 = dispatch_time(DISPATCH_TIME_NOW, delay * NSEC_PER_SEC);
        dispatch_after(pop2, dispatch_get_main_queue(), ^(void){
            [self pauseLayer:caShape2];[self pauseLayer:caLayer2];});
        delay += 1.5;
        dispatch_time_t pop3 = dispatch_time(DISPATCH_TIME_NOW, delay * NSEC_PER_SEC);
        dispatch_after(pop3, dispatch_get_main_queue(), ^(void){
            [self resumeLayer:caShape2];[self resumeLayer:caLayer2];});
    }
    else if ([sign isEqualToString:@"Both"] == true) {
            }
    
}

@end

