//
//  SecondView.m
//  TicTacToe
//
//  Created by Kerim Njuhović on 5/2/14.
//  Copyright (c) 2014 Apple. All rights reserved.
//

#import "SecondView.h"

static int gameMode = 0;
static double delayInSeconds;
@interface SecondView ()
@end

@implementation SecondView

@synthesize background;
@synthesize bC1,bC2;
@synthesize x = _x, y = _y,backC1,backC2,backC3,backC4,backC5;
@synthesize brainButton, twoplayersButton;// smartphonesButton;
@synthesize bgColorButton, lineColorButton,gameModeButton;
@synthesize userSelected, backColor2;
int oneClick = 0;

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"back"]){
        
    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIImageView *wallpaper = [[UIImageView alloc] initWithImage:background];
    wallpaper.frame = self.view.bounds;
    [self.view addSubview:wallpaper];
    [self.view sendSubviewToBack:wallpaper];
    [self enableSomeButtons];
    userSelected = 0;
    wallpaper = NULL;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)backButton:(id)sender {
    //  [self.delegate passGameModeBack:@"Changed YupiiiiYeeee\n"];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)lineColor:(id)sender {
    userSelected ++;
    bgColorButton.enabled = NO;
    gameModeButton.enabled = NO;
    [self disableButtons:backC1 and:backC2 and:backC3 and:backC4 and:backC5];
    [self disableButtons:brainButton and:nil and:twoplayersButton and:bC1 and:bC2];
    [self enableButtons:bC1 and:bC2 and:nil and:nil and:nil];
    if (userSelected == 1){
        delayInSeconds = 0.5;
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [self.view.layer insertSublayer:[self fillCircleWithColor:bC1.frame.origin.x and:bC1.frame.origin.y color:[self color6]] atIndex:3];[self playSound];});
        
        delayInSeconds += 0.28;
        popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [self.view.layer insertSublayer:[self fillCircleWithColor:bC2.frame.origin.x and:bC2.frame.origin.y color:[self color7]] atIndex:4];[self playSound];[self enableButtons:bC1 and:bC2 and:nil and:nil and:nil];});
    }
}

- (IBAction)backgroundColor:(id)sender {
    delayInSeconds = 0.6;
    lineColorButton.enabled = NO;
    gameModeButton.enabled = NO;
    [self disableButtons:bC2 and:bC1 and:brainButton and:twoplayersButton and:nil];
    [self disableButtons:backC1 and:backC2 and:backC3 and:backC4 and:backC5];
    userSelected ++;
    if (userSelected == 1){
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [self.view.layer insertSublayer:[self  fillCircleWithColor:backC1.frame.origin.x and:backC1.frame.origin.y color:[self color4]] atIndex:15];[self playSound];});
        
        delayInSeconds += 0.28;
        popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [self.view.layer insertSublayer:[self fillCircleWithColor:backC2.frame.origin.x and:backC2.frame.origin.y color:[self color5]] atIndex:16];[self playSound];});
        
        delayInSeconds += 0.28;
        popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [self.view.layer insertSublayer:[self fillCircleWithColor:backC3.frame.origin.x and:backC3.frame.origin.y color:[self color3]] atIndex:17];[self playSound];});
        
        delayInSeconds += 0.28;
        popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [self.view.layer insertSublayer:[self fillCircleWithColor:backC4.frame.origin.x and:backC4.frame.origin.y color:[self color1]] atIndex:18];[self playSound];});
        
        delayInSeconds += 0.28;
        popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [self.view.layer insertSublayer:[ self fillCircleWithColor:backC5.frame.origin.x and:backC5.frame.origin.y color:[self color2]] atIndex:19];[self playSound];;});
    }
    double delay = 2.1;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delay * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [self enableButtons:backC1 and:backC2 and:backC3 and:backC4 and:backC5];});
    delay = 0;
}

- (IBAction)gameMode:(id)sender {
    UIImage *buttonImage;
    delayInSeconds = 0.5;
    lineColorButton.enabled = NO;
    bgColorButton.enabled = NO;
    [self disableButtons:backC1 and:backC2 and:backC3 and:backC4 and:backC5];
    [self disableButtons:bC1 and:bC2 and:brainButton and:nil and:nil];
    [self enableButtons:brainButton and:twoplayersButton and:nil and:nil and:nil];
    userSelected ++;
    if (userSelected == 1){
        buttonImage = [UIImage imageNamed:@"brain-512.png"];
        dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [brainButton setBackgroundImage:buttonImage forState:UIControlStateNormal];
            [self.view addSubview:brainButton];[self playSound];});
        
        delayInSeconds += 0.28;
        buttonImage = [UIImage imageNamed:@"group-512.png"];
        popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [twoplayersButton setBackgroundImage:buttonImage forState:UIControlStateNormal];
            [self.view addSubview:twoplayersButton];[self playSound];});
        
  /*      delayInSeconds += 0.28;
        buttonImage = [UIImage imageNamed:@"two_smartphones-512.png"];
        popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
        dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
            [smartphonesButton setBackgroundImage:buttonImage forState:UIControlStateNormal];
            [self.view addSubview:smartphonesButton];[self playSound];});     */
    }
    buttonImage = NULL;
}

- (IBAction)lineColor1:(id)sender {
    [self disableButtons:bC2 and:nil and:nil and:nil and:nil];
    oneClick ++;
    if (oneClick == 1){
        _x = bC1.frame.origin.x;
        _y = bC1.frame.origin.y;
        [self.view.layer insertSublayer:[self drawCircleWith:_x and:_y color:[UIColor whiteColor]] atIndex:1];  //20
        [self disappearLineColors:1];
        [self.delegate passXandOlineColor:@"Gray"];
    }
    
}

- (IBAction)lineColor2:(id)sender {
    [self disableButtons:bC1 and:nil and:nil and:nil and:nil];
    oneClick ++;
    if (oneClick == 1){
        _x = bC2.frame.origin.x;
        _y = bC2.frame.origin.y;
        [self.view.layer insertSublayer:[self drawCircleWith:_x and:_y color:[UIColor whiteColor]] atIndex:2];   //21
        [self disappearLineColors:2];
        [self.delegate passXandOlineColor:@"Cyan"];
    }
}

- (IBAction)backgroundColor1:(id)sender {
    [self disableButtons:backC1 and:backC2 and:backC3 and:backC4 and:backC5];
    oneClick ++;
    if (oneClick == 1){
        backColor2 = [self color1];
        _x = backC1.frame.origin.x;
        _y = backC1.frame.origin.y;
        [self.view.layer insertSublayer:[self drawCircleWith:_x and:_y color:[UIColor whiteColor]] atIndex:10];
        [self disappearDotsAndCircleAtIndex:10];
        [self.delegate passBackgroundColor:255/255.0f and:124/255.0f and:71/255.0f and:1.0f];
    }
}

- (IBAction)backgroundColor2:(id)sender {
    [self disableButtons:backC1 and:backC2 and:backC3 and:backC4 and:backC5];
    oneClick ++;
    if (oneClick == 1){
        backColor2 = [self color2];
        _x = backC2.frame.origin.x;
        _y = backC2.frame.origin.y;
        [self.view.layer insertSublayer:[self drawCircleWith:_x and:_y color:[UIColor whiteColor]] atIndex:11];
        [self disappearDotsAndCircleAtIndex:11];
        [self.delegate passBackgroundColor:255/255.0f and:234/255.0f and:91/255.0f and:1.0f];
    }
}

- (IBAction)backgroundColor3:(id)sender {
    [self disableButtons:backC1 and:backC2 and:backC3 and:backC4 and:backC5];
    oneClick ++;
    if (oneClick == 1){
        backColor2 = [self color3];
        _x = backC3.frame.origin.x;
        _y = backC3.frame.origin.y;
        [self.view.layer insertSublayer:[self drawCircleWith:_x and:_y color:[UIColor whiteColor]] atIndex:12];
        [self disappearDotsAndCircleAtIndex:12];
        [self.delegate passBackgroundColor:146/255.0f and:244/255.0f and:158/255.0f and:1.0f];
    }
}

- (IBAction)backgroundColor4:(id)sender {
    [self disableButtons:backC1 and:backC2 and:backC3 and:backC4 and:backC5];
    oneClick ++;
    if (oneClick == 1){
        backColor2 = [self color4];
        _x = backC4.frame.origin.x;
        _y = backC4.frame.origin.y;
        [self.view.layer insertSublayer:[self drawCircleWith:_x and:_y color:[UIColor whiteColor]] atIndex:13];
        [self disappearDotsAndCircleAtIndex:13];
        [self.delegate passBackgroundColor:97/255.0f and:191/255.0f and:219/255.0f and:1.0f];
    }
}

- (IBAction)backgroundColor5:(id)sender {
    [self disableButtons:backC1 and:backC2 and:backC3 and:backC4 and:backC5];
    oneClick ++;
    if (oneClick == 1){
        backColor2 = [self color5];
        _x = backC5.frame.origin.x;
        _y = backC5.frame.origin.y;
        [self.view.layer insertSublayer:[self drawCircleWith:_x and:_y color:[UIColor whiteColor]] atIndex:14];
        [self disappearDotsAndCircleAtIndex:14];
        [self.delegate passBackgroundColor:219/255.0f and:142/255.0f and:234/255.0f and:1.0f];
    }
}

- (IBAction)brainMode:(id)sender {
    gameMode = 1;
    oneClick ++;
    if (oneClick == 1){
        _x = (brainButton.frame.origin.x)-5;
        _y = (brainButton.frame.origin.y)-5;
        [self.view.layer insertSublayer:[self drawCircle:_x and:_y color:[UIColor blackColor]] atIndex:7];  //22
        [self disappearGameModeAndCircle:7];
        [self.delegate passGameModeBack:@"Brain"];
    }
}

- (IBAction)twoPlayers:(id)sender {
    gameMode = 0;
    oneClick ++;
    if (oneClick == 1){
        _x = (twoplayersButton.frame.origin.x)-5;
        _y = (twoplayersButton.frame.origin.y)-5;
        [self.view.layer insertSublayer:[self drawCircle:_x and:_y color:[UIColor blackColor]] atIndex:8]; //23
        [self disappearGameModeAndCircle:8];
        [self.delegate passGameModeBack:@"Friends"];
    }
}

- (IBAction)twoSmartphones:(id)sender {
  /*  oneClick ++;
    if (oneClick == 1){
        _x = (smartphonesButton.frame.origin.x)-5;
        _y = (smartphonesButton.frame.origin.y)-5;
        [self.view.layer insertSublayer:[self drawCircle:_x and:_y color:[UIColor blackColor]] atIndex:9];//24
        [self disappearGameModeAndCircle:9];
        [self.delegate passGameModeBack:@"Bluetooth"];
    }  */
}

-(CALayer *)drawCircleWith:(CGFloat)x and:(CGFloat)y color:(UIColor*)c {
    int radius = 18;
    CAShapeLayer *circle = [CAShapeLayer layer];
    circle.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, 2.0*radius, 2.0*radius)
                                             cornerRadius:radius].CGPath;
    circle.position = CGPointMake(x, y);
    circle.fillColor = [UIColor clearColor].CGColor;
    circle.strokeColor = c.CGColor;
    circle.lineWidth = 4;
    
    CABasicAnimation *drawAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    drawAnimation.duration            = 0.3; // 0.5
    drawAnimation.repeatCount         = 1.0;  // Animate only once..
    drawAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
    drawAnimation.toValue   = [NSNumber numberWithFloat:1.0f];
    [circle addAnimation:drawAnimation forKey:@"drawCircleAnimation"];
    
    return  circle;
}

-(CALayer *)fillCircleWithColor:(CGFloat)x and:(CGFloat)y color:(UIColor*)color {
    int radius = 18;
    CAShapeLayer *circle = [CAShapeLayer layer];
    circle.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, 2.0*radius, 2.0*radius)
                                             cornerRadius:radius].CGPath;
    circle.position = CGPointMake(x, y);
    circle.fillColor = color.CGColor;
    
    return  circle;
}

-(CALayer *)drawCircle:(CGFloat)x and:(CGFloat)y color:(UIColor*)c{
    
    int radius = 20;
    CAShapeLayer *circle = [CAShapeLayer layer];
    circle.path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, 2.0*radius, 2.0*radius)
                                             cornerRadius:radius].CGPath;
    circle.position = CGPointMake(x, y);
    circle.fillColor = [UIColor clearColor].CGColor;
    circle.strokeColor = c.CGColor;
    circle.lineWidth = 2;
    
    CABasicAnimation *drawAnimation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    drawAnimation.duration            = 0.3; // 0.5
    drawAnimation.repeatCount         = 1.0;  // Animate only once..
    drawAnimation.fromValue = [NSNumber numberWithFloat:0.0f];
    drawAnimation.toValue   = [NSNumber numberWithFloat:1.0f];
    [circle addAnimation:drawAnimation forKey:@"drawCircleAnimation"];
    return  circle;
}

-(UIColor*)color1 {
    return [UIColor colorWithRed:0/255.0f green:175/255.0f blue:233/255.0f alpha:1.0f];
}

-(UIColor*) color2 {
    return [UIColor colorWithRed:219/255.0f green:108/255.0f blue:208/255.0f alpha:1.0f];
}

-(UIColor*) color3 {
    return [UIColor colorWithRed:66/255.0f green:255/255.0f blue:158/255.0f alpha:1.0f];
}
// orange
-(UIColor*) color4 {
    return [UIColor colorWithRed:255/255.0f green:104/255.0f blue:60/255.0f alpha:1.0f];
}
// yellow color
-(UIColor*) color5 {
    return [UIColor colorWithRed:255/255.0f green:210/255.0f blue:8/255.0f alpha:1.0f];
}

-(UIColor*) color6 {
    return [UIColor grayColor];
}

-(UIColor*) color7 {
    return [UIColor cyanColor];
}

- (void) disappearDotsAndCircleAtIndex:(int)i {
    double delayInSeconds = 0.7;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [[self.view.layer.sublayers objectAtIndex:i] removeFromSuperlayer];;});
    delayInSeconds += 0.28;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [[self.view.layer.sublayers objectAtIndex:19] removeFromSuperlayer];[self playSound];});
    delayInSeconds += 0.28;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [[self.view.layer.sublayers objectAtIndex:18] removeFromSuperlayer];[self playSound];});
    delayInSeconds += 0.28;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [[self.view.layer.sublayers objectAtIndex:17] removeFromSuperlayer];[self playSound];});
    delayInSeconds += 0.28;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [[self.view.layer.sublayers objectAtIndex:16] removeFromSuperlayer];[self playSound];});
    delayInSeconds += 0.28;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [[self.view.layer.sublayers objectAtIndex:15] removeFromSuperlayer];[self playSound];});
    delayInSeconds += 0.5;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [self enableSomeButtons];;});
}

-(void) disappearGameModeAndCircle:(int)index{
    double delayInSeconds = 0.7;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [[self.view.layer.sublayers objectAtIndex:index] removeFromSuperlayer];;});
  /*  delayInSeconds += 0.28;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [smartphonesButton setBackgroundImage:nil forState:UIControlStateNormal];[self playSound];});   */
    delayInSeconds += 0.28;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [twoplayersButton setBackgroundImage:nil forState:UIControlStateNormal];[self playSound];});
    delayInSeconds += 0.28;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [brainButton setBackgroundImage:nil forState:UIControlStateNormal];[self playSound];});
    delayInSeconds += 0.5;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [self enableSomeButtons];;});
}

-(void) disappearLineColors:(int)index{
    double delayInSeconds = 0.7;
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [[self.view.layer.sublayers objectAtIndex:index] removeFromSuperlayer];;});
    delayInSeconds += 0.28;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [[self.view.layer.sublayers objectAtIndex:4] removeFromSuperlayer];[self playSound];});
    delayInSeconds += 0.28;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [[self.view.layer.sublayers objectAtIndex:3] removeFromSuperlayer];[self playSound];});
    delayInSeconds += 0.5;
    popTime = dispatch_time(DISPATCH_TIME_NOW, delayInSeconds * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        [self enableSomeButtons];;});
}

-(void) disableButtons: (UIButton*)button1 and:(UIButton*)button2 and:(UIButton*)button3 and:(UIButton*)button4 and:(UIButton*) button5{
    button1.enabled = NO;
    button2.enabled = NO;
    button3.enabled = NO;
    button4.enabled = NO;
    button5.enabled = NO;
}

-(void) enableButtons: (UIButton*)button1 and:(UIButton*)button2 and:(UIButton*)button3 and:(UIButton*)button4 and:(UIButton*) button5{
    button1.enabled = YES;
    button2.enabled = YES;
    button3.enabled = YES;
    button4.enabled = YES;
    button5.enabled = YES;
}

-(void) enableSomeButtons {
    lineColorButton.enabled = YES;
    bgColorButton.enabled = YES;
    gameModeButton.enabled = YES;
    [self disableButtons:backC1 and:backC2 and:backC3 and:backC4 and:backC5];
    [self disableButtons:brainButton and:twoplayersButton and:nil and:bC2 and:bC1];
    userSelected = 0;
    oneClick = 0;
}

-(void) playSound {
    SystemSoundID soundId;
    NSString *file = [[NSBundle mainBundle] pathForResource:@"blob" ofType:@"wav"];
    AudioServicesCreateSystemSoundID((__bridge CFURLRef)([NSURL fileURLWithPath:file]), &soundId);
    AudioServicesPlaySystemSound(soundId);
}





@end
