//
//  SecondView.h
//  TicTacToe
//
//  Created by Kerim Njuhović on 5/2/14.
//  Copyright (c) 2014 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
@class SecondView;
@protocol SecondViewDelegate < NSObject>

- (void) passGameModeBack:(NSString*)ModeOfGame;
- (void) passXandOlineColor:(NSString*)color;
- (void) passBackgroundColor:(float)red and:(float)green and:(float)blue and:(float)alpha;

@end

@interface SecondView : UIViewController

@property (weak, nonatomic) id <SecondViewDelegate> delegate;

- (IBAction)backButton:(id)sender;
- (IBAction)lineColor:(id)sender;
- (IBAction)backgroundColor:(id)sender;
- (IBAction)gameMode:(id)sender;
- (IBAction)lineColor1:(id)sender;
- (IBAction)lineColor2:(id)sender;
- (IBAction)backgroundColor1:(id)sender;
- (IBAction)backgroundColor2:(id)sender;
- (IBAction)backgroundColor3:(id)sender;
- (IBAction)backgroundColor4:(id)sender;
- (IBAction)backgroundColor5:(id)sender;
- (IBAction)brainMode:(id)sender;
- (IBAction)twoPlayers:(id)sender;
- (IBAction)twoSmartphones:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *backC1;
@property (weak, nonatomic) IBOutlet UIButton *backC2;
@property (weak, nonatomic) IBOutlet UIButton *backC3;
@property (weak, nonatomic) IBOutlet UIButton *backC4;
@property (weak, nonatomic) IBOutlet UIButton *backC5;
@property (weak, nonatomic) IBOutlet UIButton *bC1;
@property (weak, nonatomic) IBOutlet UIButton *bC2;
@property (weak, nonatomic) IBOutlet UIButton *brainButton;
@property (weak, nonatomic) IBOutlet UIButton *twoplayersButton;
@property (weak, nonatomic) IBOutlet UIButton *smartphonesButton;
@property (weak, nonatomic) IBOutlet UIButton *gameModeButton;
@property (weak, nonatomic) IBOutlet UIButton *bgColorButton;
@property (weak, nonatomic) IBOutlet UIButton *lineColorButton;

@property int userSelected;
@property CGFloat x;
@property CGFloat y;
@property UIImage *background;
@property UIColor *backColor2;



@end
