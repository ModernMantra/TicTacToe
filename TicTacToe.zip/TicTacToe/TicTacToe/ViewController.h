//
//  ViewController.h
//  TicTacToe
//
//  Created by Kerim Njuhović on 4/28/14.
//  Copyright (c) 2014 Apple. All rights reserved.
//
#import "SecondView.h"
#import <AudioToolbox/AudioToolbox.h>
#import <UIKit/UIKit.h>

@interface ViewController : UIViewController < SecondViewDelegate >
@property CGFloat x;
@property CGFloat y;
@property UIImage *screenshot;
@property UIImage *passingBackground;
@property UIColor *backGroundColor;
@property NSString *gameMode,*gameMode2, *TicTacLineColor;


- (IBAction)buttonOne:(id)sender;
- (IBAction)buttonTwo:(id)sender;
- (IBAction)buttonThree:(id)sender;
- (IBAction)buttonFour:(id)sender;
- (IBAction)buttonFive:(id)sender;
- (IBAction)buttonSix:(id)sender;
- (IBAction)buttonSeven:(id)sender;
- (IBAction)buttonEight:(id)sender;
- (IBAction)buttonNine:(id)sender;
- (IBAction)settingsButton:(id)sender;
- (IBAction)reset:(id)sender;
@property CAShapeLayer *caShape1,*caShape2;
@property CALayer *caLayer1,*caLayer2;
@property (weak, nonatomic) IBOutlet UILabel *highscore2;
@property (weak, nonatomic) IBOutlet UILabel *highscore1;
@property (weak, nonatomic) IBOutlet UIButton *settings;
@property (weak, nonatomic) IBOutlet UIButton *bOne;
@property (weak, nonatomic) IBOutlet UIButton *bTwo;
@property (weak, nonatomic) IBOutlet UIButton *bThree;
@property (weak, nonatomic) IBOutlet UIButton *bFour;
@property (weak, nonatomic) IBOutlet UIButton *bFive;
@property (weak, nonatomic) IBOutlet UIButton *bSix;
@property (weak, nonatomic) IBOutlet UIButton *bSeven;
@property (weak, nonatomic) IBOutlet UIButton *bEight;
@property (weak, nonatomic) IBOutlet UIButton *bNine;
@property (weak, nonatomic) IBOutlet UILabel *displayPlayer;
@property (weak, nonatomic) IBOutlet UIButton *resetGame;

@end
